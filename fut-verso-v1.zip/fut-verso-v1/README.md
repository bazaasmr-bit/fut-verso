# FUT VERSO — V1

Primeira versão navegável do conceito, inspirada na estrutura de simulador de carreira do Copero, mas com identidade e mecânicas próprias.

Inclui:
- tela inicial FUT VERSO
- criação de jogador
- @ do Instagram (modo demonstração)
- posições, países e clubes
- temporadas e evolução
- gols, títulos, valor e eventos
- GP de Followers
- ranking
- perfil
- persistência local no navegador

## Importante
Esta V1 é um protótipo front-end: os dados ficam no navegador (localStorage). Para virar uma plataforma pública real, a próxima etapa é conectar banco de dados, autenticação e a integração oficial suportada pela Meta/Instagram, além de publicar em um domínio HTTPS.
